
git check-ignore *
