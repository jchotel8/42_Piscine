/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush-02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jchotel <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/17 12:28:00 by jchotel           #+#    #+#             */
/*   Updated: 2019/08/18 19:22:27 by jchotel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <unistd.h>

int		ft_strlen(char *src)
{
	int i;

	i = 0;
	while (src[i])
		i++;
	return (i);
}

int		ft_power_10(int power)
{
	int	result;

	result = 1;
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	else
	{
		while (power > 0)
		{
			result = 10 * result;
			power--;
		}
		return (result);
	}
}

int		ft_rush(char *str, int *tab, int size, int i)
{
	int j;

	j = 0;
	while (str[++i])
	{
		if (size % 3 == 2 && str[i] != '0')
		{
			tab[j++] = (str[i] - 48);
			tab[j++] = 100;
		}
		if (size % 3 == 1 && str[i] != '0' && str[i] != '1')
			tab[j++] = ((str[i] - 48) * 10);
		if (size % 3 == 0)
		{
			if (str[i - 1] == '1')
				tab[j++] = str[i] - 38;
			else if (str[i] != 48)
				tab[j++] = str[i] - 48;
			if (size > 0 && (str[i - 2] != '0'
						|| str[i - 1] != '0' || str[i] != '0'))
				tab[j++] = ft_power_10(size);
		}
		size--;
	}
	return (j);
}

void	affichage(int *tab, int taille)
{
	int i;

	i = -1;
	while (++i < taille)
	{
		printf("%d\n", tab[i]);
		if (tab[i] >= 1000 && i != taille)
			printf(", ");
		if (tab[i] < 100 && tab[i] >= 20 && tab[i + 1] <= 9 && tab[i + 1] >= 1)
			printf("-");
		if ((tab[i] == 100 || tab[i] == 1000 || tab[i] == 1000000)
				&& tab[i + 1] < 100)
			printf("and ");
	}
}

int		*ft_numbers(char *str)
{
	int i;
	int *tab;
	int taille;
	int a;
	int j;

	i = -1;
	a = -1;
	taille = ft_strlen(str) - 1;
	if (!(tab = malloc(sizeof(int) * ((taille * 2)))))
		return (0);
	affichage(tab, ft_rush(str, tab, size, a));
	return (tab);
}

int		main(int ac, char **av)
{
	ft_numbers(av[1]);
	return (0);
}
