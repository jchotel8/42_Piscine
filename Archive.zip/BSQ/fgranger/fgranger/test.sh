perl generator.pl 30 15 1 > test
./bsq test
