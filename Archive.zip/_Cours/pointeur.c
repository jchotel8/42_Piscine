#include <unistd.h>

void ft_putchar(char c)
{
  write(1, &c, 1);
}


void ft_putstr(char *str)
{
  int i;

  i = 0;
  while(str[i] != '\0')
  {
    write(1, &str[i], 1);
    i++;
  }
}

// void ft_putstr(char *str)
// {
//   int i;

//   i = 0;
//   while(str[i] != '\0')
//   {
//     ft_putchar(str[i]);
//     i++;
//   }
// }

// void ft_putstr(char *str)
// {
//   int i;

//   i = 0;
//   while(str[i])
//     ft_putchar(str[i++]);
// }

// void ft_putstr(char *str)
// {
//   // while the value of the string is not \0
//   while(*str)
//     // write the character and go to the next address
//     write(1, str++, 1);
// }

// void ft_putstr(char *str)
// {
//   while(*str)
//     ft_putchar(*str++);
// }

int main(int argc, char **argv)
{
    int i;
    
    i = 1;
    if (argc > 1) 
    {
      while(argc-- > 1) 
      {
        ft_putstr(argv[i++]);
        write(1, "\n", 1);
      }
    } 
    else 
      write(1, "\n", 1);
    return (0);
}