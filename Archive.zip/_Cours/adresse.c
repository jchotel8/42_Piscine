int main(void)
{
	char str[] = "Hello";

	printf("%p\n", str);
	
	unsigned long int adresse;

	adresse = (unsigned long int)str;

	printf("%lu", adresse);
	return(0);
}
