int        atoiSimon(char *str)
{
    int i;
    int count;
    int sign;
    int result;
    
    i = 0;
    count = 0;
    sign = 1;
    result = 0;
    while (str[i] == '\f' || str[i] == '\n'|| str[i] == '\r' || str[i] == '\t' || str[i] == '\v')
        str[i]++;
    while (str[i] == '-' || str[i] == '+')
    {
        if (str[i] == '-')
            count++;
        i++;
    }
    if (count % 2 != 0)
        sign = -1;
    while (str[i++] >= '0' && str[i - 1] <= '9')
        result = result * 10 + str[i - 1] - 48;
    return (result * sign);
}
